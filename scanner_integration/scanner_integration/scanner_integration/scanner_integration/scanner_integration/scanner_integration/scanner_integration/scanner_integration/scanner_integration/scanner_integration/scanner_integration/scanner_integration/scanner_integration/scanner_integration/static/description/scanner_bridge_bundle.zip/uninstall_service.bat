@echo off
echo ========================================
echo    ScannerBridge Service Uninstaller
echo ========================================
echo.

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo ERROR: Please run as Administrator!
    pause
    exit /b 1
)

set NSSM_PATH=C:\scanner_bridge\nssm.exe

:: Remove NSSM service
if exist "%NSSM_PATH%" (
    "%NSSM_PATH%" stop ScannerBridge >nul 2>&1
    "%NSSM_PATH%" remove ScannerBridge confirm >nul 2>&1
    echo [OK] NSSM service removed.
)

:: Remove Task Scheduler task
schtasks /end /tn "ScannerBridge" >nul 2>&1
schtasks /delete /tn "ScannerBridge" /f >nul 2>&1
echo [OK] Task Scheduler task removed.

:: Remove firewall rule
netsh advfirewall firewall delete rule name="ScannerBridge" >nul 2>&1
echo [OK] Firewall rule removed.

echo.
echo [OK] ScannerBridge fully uninstalled!
pause
