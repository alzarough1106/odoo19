@echo off
echo ========================================
echo    ScannerBridge Service Installer
echo ========================================
echo.

:: Check for Administrator privileges
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo ERROR: Please run this script as Administrator!
    echo Right-click install_service.bat and select "Run as administrator"
    pause
    exit /b 1
)

:: Set paths
set INSTALL_DIR=C:\scanner_bridge
set EXE_PATH=%INSTALL_DIR%\scanner_bridge.exe
set LOGS_DIR=%INSTALL_DIR%\logs
set NSSM_PATH=%INSTALL_DIR%\nssm.exe

:: Check if scanner_bridge.exe exists
if not exist "%EXE_PATH%" (
    echo ERROR: scanner_bridge.exe not found in %INSTALL_DIR%
    echo Please make sure scanner_bridge.exe is in %INSTALL_DIR%
    pause
    exit /b 1
)

:: Create logs folder
if not exist "%LOGS_DIR%" mkdir "%LOGS_DIR%"
echo [OK] Logs folder ready: %LOGS_DIR%

:: Remove existing service if it exists
sc query ScannerBridge >nul 2>&1
if %errorLevel% equ 0 (
    echo [INFO] Existing ScannerBridge service found. Removing it...
    if exist "%NSSM_PATH%" (
        "%NSSM_PATH%" stop ScannerBridge >nul 2>&1
        "%NSSM_PATH%" remove ScannerBridge confirm >nul 2>&1
    ) else (
        sc stop ScannerBridge >nul 2>&1
        sc delete ScannerBridge >nul 2>&1
    )
    echo [OK] Old service removed.
    timeout /t 2 >nul
)

:: Check if NSSM is available
if exist "%NSSM_PATH%" (
    echo [INFO] Installing using NSSM...

    "%NSSM_PATH%" install ScannerBridge "%EXE_PATH%"
    "%NSSM_PATH%" set ScannerBridge AppDirectory "%INSTALL_DIR%"
    "%NSSM_PATH%" set ScannerBridge AppStdout "%LOGS_DIR%\output.log"
    "%NSSM_PATH%" set ScannerBridge AppStderr "%LOGS_DIR%\error.log"
    "%NSSM_PATH%" set ScannerBridge AppRestartDelay 3000
    "%NSSM_PATH%" set ScannerBridge Start SERVICE_AUTO_START
    "%NSSM_PATH%" set ScannerBridge DisplayName "Scanner Bridge"
    "%NSSM_PATH%" set ScannerBridge Description "Scanner Bridge for Odoo Integration"
    "%NSSM_PATH%" start ScannerBridge

    echo [OK] Service installed and started using NSSM.

) else (
    echo [INFO] NSSM not found. Installing using Task Scheduler instead...

    :: Remove existing task if any
    schtasks /delete /tn "ScannerBridge" /f >nul 2>&1

    :: Create task scheduler entry
    schtasks /create /tn "ScannerBridge" /tr "%EXE_PATH%" /sc onlogon /rl highest /ru "%USERNAME%" /f

    :: Start it immediately
    schtasks /run /tn "ScannerBridge"

    echo [OK] Task Scheduler entry created and started.
)

:: Verify it's running
echo.
echo ========================================
echo Verifying installation...
echo ========================================
timeout /t 3 >nul

netstat -ano | findstr :8765 >nul 2>&1
if %errorLevel% equ 0 (
    echo [OK] ScannerBridge is running and listening on port 8765!
) else (
    echo [WARNING] Port 8765 not detected yet. Check logs at:
    echo %LOGS_DIR%\error.log
)

:: Add firewall rule
echo.
echo [INFO] Adding Windows Firewall rule...
netsh advfirewall firewall delete rule name="ScannerBridge" >nul 2>&1
netsh advfirewall firewall add rule name="ScannerBridge" dir=in action=allow program="%EXE_PATH%" enable=yes
echo [OK] Firewall rule added.

echo.
echo ========================================
echo    Installation Complete!
echo ========================================
echo.
echo To check logs: type %LOGS_DIR%\error.log
echo To stop service: nssm stop ScannerBridge  (or schtasks /end /tn "ScannerBridge")
echo To uninstall: run uninstall_service.bat
echo.
pause
